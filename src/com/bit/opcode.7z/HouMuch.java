package com.bit.opcode;

import java.util.Scanner;

public class HouMuch {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int much = 0, num = 0, sum = 0, dc = 0;
		int total = 0;
		String result = "";
		System.out.print("얼마에요?");
		much = s.nextInt();
		System.out.print(much + "원입니다.");
		System.out.print("몇개 드릴까요");
		num = s.nextInt();
		System.out.print(num + "개 드릴게요\n");
		sum = (much*num);
		System.out.print("총 금액은 " + sum + "입니다.\n");
		System.out.print("비싸요. 깍아주세요?\n");
		System.out.print("몇 퍼센트 DC 할께요?\n");
		dc = s.nextInt();
		total = sum*(100-dc)/100 ;
		if(dc<10){
			System.out.println("그럼" + total + "원만 주세요.");
		}else if(dc>=10) {
			System.out.println("안 팔아요.");
		}
	}
}	
		
		
//		switch(dc) {
//			case 9:
//				result = "그럼 total 원만 주세요.";
//				break;
//			default :
//				result = "안 팔아요.";
//				break;
		
		
		
//		//10퍼센트 이하이면
//		System.out.print("그럼 몇원만 주세요.");
//		//10퍼센트 이상이면
//		System.out.print("안 팔아요.");
//		System.out.print("475원 입니다.");
		



